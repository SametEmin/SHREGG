using UnityEngine;

public class bulletHit : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Enemy touched the player!");
            // Example: Reduce player health or destroy the enemy
            
            Destroy(gameObject);
        }
    }
}
