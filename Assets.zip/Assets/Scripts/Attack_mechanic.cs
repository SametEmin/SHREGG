using UnityEngine;

public class Attack_mechanic : MonoBehaviour
{
    public float speed = 5f; // Speed of the character
    public float attackCooldown = 0.5f; // Time between attacks
    private float lastAttackTime = 0f;

    public Transform swordTransform; // Reference to the sword's transform
    public float swordSwingDuration = 0.2f; // Duration of the sword swing
    private bool isSwinging = false;

    void Update()
    {
        HandleAttack();
    }


    private void HandleAttack()
    {
        // Check if the attack key is pressed and if the cooldown has passed
        if (Input.GetKeyDown(KeyCode.Space) && Time.time >= lastAttackTime + attackCooldown && !isSwinging)
        {
            // Perform the sword swing
            StartCoroutine(SwingSword());

            // Update the last attack time
            lastAttackTime = Time.time;
        }
    }

    private System.Collections.IEnumerator SwingSword()
    {
        isSwinging = true;

        // Enable the sword's collider or visual representation
        swordTransform.gameObject.SetActive(true);

        // Optionally, play a sword swing animation or sound here

        // Wait for the duration of the sword swing
        yield return new WaitForSeconds(swordSwingDuration);

        // Disable the sword's collider or visual representation
        swordTransform.gameObject.SetActive(false);

        isSwinging = false;
    }
}