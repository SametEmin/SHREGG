using UnityEngine;

public class EnemyFollow : MonoBehaviour
{
    public float speed = 3f;
    private Transform player;
    private Rigidbody2D rb;
    private Vector2 movement;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        FindPlayer();
    }

    void Update()
    {
        if (player == null)
        {
            FindPlayer(); // Keep checking in case the player was not found at start
            return;
        }

        // Calculate direction towards player
        Vector2 direction = (player.position - transform.position).normalized;
        movement = direction * speed;
    }

    void FixedUpdate()
    {
        // Move the enemy
        rb.linearVelocity = movement;
    }

    void FindPlayer()
    {
        GameObject foundPlayer = GameObject.FindGameObjectWithTag("Player"); // Look for a GameObject with the "Player" tag
        if (foundPlayer != null)
        {
            player = foundPlayer.transform;
        }
    }
}
