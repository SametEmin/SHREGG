using UnityEngine;

public class Player : MonoBehaviour
{
    public int maxHealth = 100;
    private int currentHealth;

    public int damage = 10; // Damage dealt by the player
    public float speed = 5f; // Movement speed of the player
    public float range = 1.5f; // Attack range of the player
    public int armor = 5; // Armor reduces incoming damage
    public float attackCooldown = 1f; // Time between attacks
    private float lastAttackTime = 0f;
    

    public Animator animator; // Reference to the Animator component for attack animation

    void Start()
    {
        currentHealth = maxHealth;
    }

    void Update()
    {
        DetectAndAttackEnemies();
    }

    void DetectAndAttackEnemies()
    {
        if (Time.time >= lastAttackTime + attackCooldown)
        {
            Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, range);
            foreach (Collider2D collider in hitEnemies)
            {
                if (collider.CompareTag("Enemy"))
                {
                    Attack(collider.GetComponent<Enemy>());
                    lastAttackTime = Time.time;
                    break; // Attack one enemy at a time
                }
            }
        }
    }

    void Attack(Enemy enemy)
    {
        // Play attack animation
        if (animator != null)
        {
            animator.SetTrigger("Attack");
        }

        // Deal damage to the enemy
        if (enemy != null)
        {
            enemy.TakeDamage(damage);
        }
    }

    public void TakeDamage(int incomingDamage)
    {
        int damageTaken = Mathf.Max(incomingDamage - armor, 0);
        currentHealth -= damageTaken;
        Debug.Log("Player took damage, current health: " + currentHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log("Player died!");
        // Add death logic here, such as triggering a game over screen
    }

    public void Heal(int amount)
    {
        currentHealth += amount;
        if (currentHealth > maxHealth)
        {
            currentHealth = maxHealth;
        }
        Debug.Log("Player healed, current health: " + currentHealth);
    }

    public void ModifyDamage(int amount)
    {
        damage += amount;
        Debug.Log("Player damage modified, current damage: " + damage);
    }

    public void ModifySpeed(float amount)
    {
        speed += amount;
        Debug.Log("Player speed modified, current speed: " + speed);
    }

    public void ModifyRange(float amount)
    {
        range += amount;
        Debug.Log("Player range modified, current range: " + range);
    }

    public void ModifyArmor(int amount)
    {
        armor += amount;
        Debug.Log("Player armor modified, current armor: " + armor);
    }

    // Optional: Visualize the attack range in the editor
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, range);
    }
}